#[derive(PartialOrd, PartialEq)]
pub enum ArrayTraces {
    OverColumns,
    OverRows,
}
